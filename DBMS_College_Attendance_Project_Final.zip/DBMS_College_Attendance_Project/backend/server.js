const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const crypto = require('crypto');
const path = require('path');
require('dotenv').config();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const APP_SALT = 'COLLEGE_ATTENDANCE_DEMO_SALT';

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'frontend')));

const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'college_attendance',
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

function hashPassword(password) {
  return crypto.createHash('sha256').update(password + APP_SALT).digest('hex');
}

async function query(sql, params = []) {
  const [rows] = await pool.execute(sql, params);
  return rows;
}

app.get('/api/health', async (_req, res) => {
  try {
    await query('SELECT 1 AS ok');
    res.json({ ok: true, database: 'connected' });
  } catch (err) {
    res.status(503).json({ ok: false, database: 'disconnected', message: err.message });
  }
});

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({ message: 'Username and password are required.' });
  try {
    const rows = await query(
      'SELECT user_id, username, role FROM users WHERE username = ? AND password_hash = ? AND is_active = TRUE',
      [username, hashPassword(password)]
    );
    if (!rows.length) return res.status(401).json({ message: 'Invalid credentials.' });
    res.json({ message: 'Login successful', user: rows[0] });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.get('/api/dashboard/stats', async (_req, res) => {
  try {
    const [students, subjects, faculty, lowAttendance] = await Promise.all([
      query('SELECT COUNT(*) AS count FROM students'),
      query('SELECT COUNT(*) AS count FROM subjects'),
      query('SELECT COUNT(*) AS count FROM faculty'),
      query('SELECT COUNT(*) AS count FROM v_student_attendance_summary WHERE attendance_percentage < 75')
    ]);
    res.json({
      students: students[0].count,
      subjects: subjects[0].count,
      faculty: faculty[0].count,
      lowAttendance: lowAttendance[0].count
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

app.get('/api/students', async (_req, res) => {
  try {
    const rows = await query(`
      SELECT s.student_id, s.roll_no, s.name, s.email, s.phone, s.year_level, s.section,
             d.department_code, d.department_name
      FROM students s
      JOIN departments d ON s.department_id = d.department_id
      ORDER BY s.student_id
    `);
    res.json(rows);
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.post('/api/students', async (req, res) => {
  const { roll_no, name, email, phone, department_id, year_level, section } = req.body || {};
  try {
    const result = await query(
      `INSERT INTO students(roll_no,name,email,phone,department_id,year_level,section)
       VALUES(?,?,?,?,?,?,?)`,
      [roll_no, name, email, phone || null, department_id, year_level, section]
    );
    res.status(201).json({ student_id: result.insertId });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

app.put('/api/students/:id', async (req, res) => {
  const { roll_no, name, email, phone, department_id, year_level, section } = req.body || {};
  try {
    await query(
      `UPDATE students SET roll_no=?, name=?, email=?, phone=?, department_id=?, year_level=?, section=? WHERE student_id=?`,
      [roll_no, name, email, phone || null, department_id, year_level, section, req.params.id]
    );
    res.json({ message: 'Student updated.' });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

app.delete('/api/students/:id', async (req, res) => {
  try {
    await query('DELETE FROM students WHERE student_id=?', [req.params.id]);
    res.json({ message: 'Student deleted.' });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

app.get('/api/subjects', async (_req, res) => {
  try {
    res.json(await query('SELECT subject_id, subject_code, subject_name, semester, credits FROM subjects ORDER BY subject_id'));
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.post('/api/subjects', async (req, res) => {
  const { subject_code, subject_name, semester, credits } = req.body || {};
  try {
    const result = await query(
      'INSERT INTO subjects(subject_code,subject_name,semester,credits) VALUES(?,?,?,?)',
      [subject_code, subject_name, semester, credits]
    );
    res.status(201).json({ subject_id: result.insertId });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

app.put('/api/subjects/:id', async (req, res) => {
  const { subject_code, subject_name, semester, credits } = req.body || {};
  try {
    await query(
      'UPDATE subjects SET subject_code=?, subject_name=?, semester=?, credits=? WHERE subject_id=?',
      [subject_code, subject_name, semester, credits, req.params.id]
    );
    res.json({ message: 'Subject updated.' });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

app.delete('/api/subjects/:id', async (req, res) => {
  try {
    await query('DELETE FROM subjects WHERE subject_id=?', [req.params.id]);
    res.json({ message: 'Subject deleted.' });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

app.get('/api/attendance/summary', async (req, res) => {
  try {
    const where = req.query.student_id ? 'WHERE student_id = ?' : '';
    const rows = await query(`SELECT * FROM v_student_attendance_summary ${where} ORDER BY student_id, subject_id`, req.query.student_id ? [req.query.student_id] : []);
    res.json(rows);
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.post('/api/attendance/mark', async (req, res) => {
  const { faculty_id, records } = req.body || {};
  if (!faculty_id || !Array.isArray(records) || records.length === 0) {
    return res.status(400).json({ message: 'faculty_id and a non-empty records array are required.' });
  }
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    for (const record of records) {
      await conn.execute(
        'INSERT INTO attendance(student_id,subject_id,attendance_date,status,marked_by) VALUES(?,?,?,?,?)',
        [record.student_id, record.subject_id, record.attendance_date, record.status, faculty_id]
      );
    }
    await conn.commit();
    res.json({ message: `${records.length} attendance record(s) saved successfully.` });
  } catch (err) {
    await conn.rollback();
    res.status(400).json({ message: err.message });
  } finally {
    conn.release();
  }
});

app.get('/api/leaves', async (_req, res) => {
  try {
    const rows = await query(`
      SELECT l.leave_id, s.roll_no, s.name AS student_name, l.from_date, l.to_date,
             l.reason, l.status, l.created_at
      FROM leave_requests l
      JOIN students s ON s.student_id = l.student_id
      ORDER BY l.created_at DESC
    `);
    res.json(rows);
  } catch (err) { res.status(500).json({ message: err.message }); }
});

app.post('/api/leaves', async (req, res) => {
  const { student_id, from_date, to_date, reason } = req.body || {};
  try {
    const result = await query(
      'INSERT INTO leave_requests(student_id,from_date,to_date,reason) VALUES(?,?,?,?)',
      [student_id, from_date, to_date, reason]
    );
    res.status(201).json({ leave_id: result.insertId });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

app.put('/api/leaves/:id/status', async (req, res) => {
  const { status, faculty_id } = req.body || {};
  if (!['Approved', 'Rejected', 'Pending'].includes(status)) return res.status(400).json({ message: 'Invalid status.' });
  try {
    await query(
      'UPDATE leave_requests SET status=?, reviewed_by=?, reviewed_at=NOW() WHERE leave_id=?',
      [status, faculty_id || null, req.params.id]
    );
    res.json({ message: 'Leave request updated.' });
  } catch (err) { res.status(400).json({ message: err.message }); }
});

app.get('*', (_req, res) => {
  res.sendFile(path.join(__dirname, '..', 'frontend', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`College Attendance app running at http://localhost:${PORT}`);
});
