# Normalization Notes

## 1NF
All attributes are atomic. Each attendance record contains one student, one subject, one date and one status.

## 2NF
Non-key attributes depend on the whole primary key of their own table. Many-to-many relationships are decomposed into `enrollments` and `class_assignments`.

## 3NF-oriented design
Department details are separated into `departments`, student details into `students`, faculty details into `faculty`, and subject details into `subjects`. This reduces redundancy and update anomalies.
