-- Quick SQL demonstration queries for lab/project screenshots
USE college_attendance;

-- 1. All students
SELECT * FROM students;

-- 2. Student + department JOIN
SELECT s.roll_no, s.name, d.department_name
FROM students s JOIN departments d ON s.department_id = d.department_id;

-- 3. Attendance JOIN
SELECT s.roll_no, s.name, sub.subject_name, a.attendance_date, a.status
FROM attendance a
JOIN students s ON a.student_id=s.student_id
JOIN subjects sub ON a.subject_id=sub.subject_id
ORDER BY a.attendance_date DESC;

-- 4. Attendance percentage / low attendance
SELECT * FROM v_student_attendance_summary
WHERE attendance_percentage < 75;

-- 5. Aggregation
SELECT sub.subject_code, COUNT(a.attendance_id) AS records,
       SUM(a.status='Present') AS present_count,
       ROUND(SUM(a.status='Present')/COUNT(a.attendance_id)*100,2) AS present_percentage
FROM attendance a
JOIN subjects sub ON sub.subject_id=a.subject_id
GROUP BY sub.subject_id, sub.subject_code;

-- 6. Stored procedure
CALL sp_get_student_attendance(1);

-- 7. Transaction example
START TRANSACTION;
UPDATE leave_requests SET status='Approved' WHERE leave_id=1;
SELECT * FROM leave_requests WHERE leave_id=1;
COMMIT;
