-- ============================================================
-- Smart College Attendance & Leave Management System
-- MySQL 8.0+
-- ============================================================

DROP DATABASE IF EXISTS college_attendance;
CREATE DATABASE college_attendance;
USE college_attendance;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS leave_requests;
DROP TABLE IF EXISTS attendance;
DROP TABLE IF EXISTS enrollments;
DROP TABLE IF EXISTS class_assignments;
DROP TABLE IF EXISTS subjects;
DROP TABLE IF EXISTS faculty;
DROP TABLE IF EXISTS students;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS departments;

SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE departments (
    department_id INT AUTO_INCREMENT PRIMARY KEY,
    department_code VARCHAR(20) NOT NULL UNIQUE,
    department_name VARCHAR(100) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(100) NOT NULL UNIQUE,
    password_hash CHAR(64) NOT NULL,
    role ENUM('ADMIN','FACULTY','STUDENT') NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE students (
    student_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE,
    roll_no VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20),
    department_id INT NOT NULL,
    year_level TINYINT NOT NULL,
    section CHAR(1) NOT NULL,
    CONSTRAINT chk_student_year CHECK (year_level BETWEEN 1 AND 4),
    CONSTRAINT fk_student_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    CONSTRAINT fk_student_department FOREIGN KEY (department_id) REFERENCES departments(department_id)
) ENGINE=InnoDB;

CREATE TABLE faculty (
    faculty_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNIQUE,
    employee_code VARCHAR(30) NOT NULL UNIQUE,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    department_id INT NOT NULL,
    CONSTRAINT fk_faculty_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL,
    CONSTRAINT fk_faculty_department FOREIGN KEY (department_id) REFERENCES departments(department_id)
) ENGINE=InnoDB;

CREATE TABLE subjects (
    subject_id INT AUTO_INCREMENT PRIMARY KEY,
    subject_code VARCHAR(30) NOT NULL UNIQUE,
    subject_name VARCHAR(150) NOT NULL,
    semester TINYINT NOT NULL,
    credits TINYINT NOT NULL DEFAULT 3,
    CONSTRAINT chk_subject_semester CHECK (semester BETWEEN 1 AND 8),
    CONSTRAINT chk_subject_credits CHECK (credits BETWEEN 1 AND 8)
) ENGINE=InnoDB;

CREATE TABLE class_assignments (
    assignment_id INT AUTO_INCREMENT PRIMARY KEY,
    faculty_id INT NOT NULL,
    subject_id INT NOT NULL,
    year_level TINYINT NOT NULL,
    section CHAR(1) NOT NULL,
    semester TINYINT NOT NULL,
    CONSTRAINT uq_class_assignment UNIQUE (faculty_id, subject_id, year_level, section, semester),
    CONSTRAINT fk_assignment_faculty FOREIGN KEY (faculty_id) REFERENCES faculty(faculty_id),
    CONSTRAINT fk_assignment_subject FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
    CONSTRAINT chk_assignment_year CHECK (year_level BETWEEN 1 AND 4)
) ENGINE=InnoDB;

CREATE TABLE enrollments (
    enrollment_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    semester TINYINT NOT NULL,
    academic_year VARCHAR(9) NOT NULL,
    CONSTRAINT uq_enrollment UNIQUE (student_id, subject_id, semester, academic_year),
    CONSTRAINT fk_enrollment_student FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_enrollment_subject FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
    CONSTRAINT chk_enrollment_semester CHECK (semester BETWEEN 1 AND 8)
) ENGINE=InnoDB;

CREATE TABLE attendance (
    attendance_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    attendance_date DATE NOT NULL,
    status ENUM('Present','Absent') NOT NULL,
    marked_by INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uq_attendance UNIQUE (student_id, subject_id, attendance_date),
    CONSTRAINT fk_attendance_student FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_attendance_subject FOREIGN KEY (subject_id) REFERENCES subjects(subject_id),
    CONSTRAINT fk_attendance_faculty FOREIGN KEY (marked_by) REFERENCES faculty(faculty_id)
) ENGINE=InnoDB;

CREATE TABLE leave_requests (
    leave_id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    from_date DATE NOT NULL,
    to_date DATE NOT NULL,
    reason VARCHAR(500) NOT NULL,
    status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
    reviewed_by INT NULL,
    reviewed_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_leave_dates CHECK (to_date >= from_date),
    CONSTRAINT fk_leave_student FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    CONSTRAINT fk_leave_reviewer FOREIGN KEY (reviewed_by) REFERENCES faculty(faculty_id) ON DELETE SET NULL
) ENGINE=InnoDB;

-- Default demo users. Password for all three is: admin123 / faculty123 / student123
-- Hashing rule used by the Node.js app: SHA256(password + APP_SALT).
INSERT INTO users(username, password_hash, role) VALUES
('admin@college.local', SHA2(CONCAT('admin123','COLLEGE_ATTENDANCE_DEMO_SALT'),256), 'ADMIN'),
('faculty@college.local', SHA2(CONCAT('faculty123','COLLEGE_ATTENDANCE_DEMO_SALT'),256), 'FACULTY'),
('student@college.local', SHA2(CONCAT('student123','COLLEGE_ATTENDANCE_DEMO_SALT'),256), 'STUDENT');

INSERT INTO departments(department_code, department_name) VALUES
('CSE','Computer Science and Engineering'),
('ETC','Electronics and Telecommunication'),
('ME','Mechanical Engineering');

INSERT INTO students(user_id, roll_no, name, email, phone, department_id, year_level, section) VALUES
(3,'CSE-101','Aditya Shende','student@college.local','9999999999',1,2,'A'),
(NULL,'CSE-102','Riya Patil','riya@college.local','9999999998',1,2,'A'),
(NULL,'CSE-103','Aman Verma','aman@college.local','9999999997',1,2,'A'),
(NULL,'CSE-104','Neha Joshi','neha@college.local','9999999996',1,2,'A');

INSERT INTO faculty(user_id, employee_code, name, email, department_id) VALUES
(2,'FAC-001','Dr. Rahul Kulkarni','faculty@college.local',1),
(NULL,'FAC-002','Prof. Sneha Deshmukh','sneha.faculty@college.local',1);

INSERT INTO subjects(subject_code, subject_name, semester, credits) VALUES
('DBMS','Database Management Systems',4,4),
('CN','Computer Networks',4,4),
('SEPM','Software Engineering and Project Management',4,3),
('DAA','Design and Analysis of Algorithms',4,4);

INSERT INTO class_assignments(faculty_id, subject_id, year_level, section, semester) VALUES
(1,1,2,'A',4),
(1,3,2,'A',4),
(2,2,2,'A',4),
(2,4,2,'A',4);

INSERT INTO enrollments(student_id, subject_id, semester, academic_year)
SELECT s.student_id, sub.subject_id, 4, '2026-27'
FROM students s CROSS JOIN subjects sub;

DELIMITER $$

CREATE TRIGGER trg_before_attendance_insert
BEFORE INSERT ON attendance
FOR EACH ROW
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM enrollments e
        WHERE e.student_id = NEW.student_id
          AND e.subject_id = NEW.subject_id
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Student is not enrolled in the selected subject.';
    END IF;

    IF EXISTS (
        SELECT 1 FROM attendance a
        WHERE a.student_id = NEW.student_id
          AND a.subject_id = NEW.subject_id
          AND a.attendance_date = NEW.attendance_date
    ) THEN
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Attendance already exists for this student, subject and date.';
    END IF;
END$$

CREATE PROCEDURE sp_get_student_attendance(IN p_student_id INT)
BEGIN
    SELECT
        s.name AS student_name,
        s.roll_no,
        sub.subject_code,
        sub.subject_name,
        COUNT(a.attendance_id) AS total_classes,
        SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) AS present_classes,
        SUM(CASE WHEN a.status = 'Absent' THEN 1 ELSE 0 END) AS absent_classes,
        ROUND(
            (SUM(CASE WHEN a.status = 'Present' THEN 1 ELSE 0 END) / NULLIF(COUNT(a.attendance_id),0)) * 100,
            2
        ) AS attendance_percentage
    FROM students s
    JOIN attendance a ON s.student_id = a.student_id
    JOIN subjects sub ON a.subject_id = sub.subject_id
    WHERE s.student_id = p_student_id
    GROUP BY s.student_id, sub.subject_id;
END$$

CREATE PROCEDURE sp_mark_attendance(
    IN p_student_id INT,
    IN p_subject_id INT,
    IN p_attendance_date DATE,
    IN p_status VARCHAR(10),
    IN p_faculty_id INT
)
BEGIN
    INSERT INTO attendance(student_id, subject_id, attendance_date, status, marked_by)
    VALUES(p_student_id, p_subject_id, p_attendance_date, p_status, p_faculty_id);
END$$

DELIMITER ;

CREATE OR REPLACE VIEW v_student_attendance_summary AS
SELECT
    s.student_id,
    s.roll_no,
    s.name AS student_name,
    sub.subject_id,
    sub.subject_code,
    sub.subject_name,
    COUNT(a.attendance_id) AS total_classes,
    COALESCE(SUM(a.status = 'Present'),0) AS present_classes,
    COALESCE(SUM(a.status = 'Absent'),0) AS absent_classes,
    ROUND((COALESCE(SUM(a.status = 'Present'),0) / NULLIF(COUNT(a.attendance_id),0)) * 100, 2) AS attendance_percentage
FROM students s
JOIN enrollments e ON s.student_id = e.student_id
JOIN subjects sub ON e.subject_id = sub.subject_id
LEFT JOIN attendance a
    ON a.student_id = s.student_id AND a.subject_id = sub.subject_id
GROUP BY s.student_id, s.roll_no, s.name, sub.subject_id, sub.subject_code, sub.subject_name;

-- Sample attendance records demonstrating realistic outputs.
INSERT INTO attendance(student_id, subject_id, attendance_date, status, marked_by) VALUES
(1,1,'2026-10-01','Present',1),
(1,1,'2026-10-02','Present',1),
(1,1,'2026-10-03','Absent',1),
(1,1,'2026-10-04','Present',1),
(1,2,'2026-10-01','Present',2),
(1,2,'2026-10-02','Present',2),
(1,2,'2026-10-03','Present',2),
(2,1,'2026-10-01','Present',1),
(2,1,'2026-10-02','Absent',1),
(3,1,'2026-10-01','Present',1),
(3,1,'2026-10-02','Present',1),
(4,1,'2026-10-01','Absent',1),
(4,1,'2026-10-02','Absent',1);

INSERT INTO leave_requests(student_id, from_date, to_date, reason, status)
VALUES
(1,'2026-10-10','2026-10-11','Family function','Pending'),
(2,'2026-10-12','2026-10-13','Medical appointment','Approved');

-- Example transaction demonstrating safe multi-row attendance insertion.
START TRANSACTION;
INSERT INTO attendance(student_id, subject_id, attendance_date, status, marked_by)
VALUES
(2,2,'2026-10-04','Present',2),
(3,2,'2026-10-04','Absent',2);
COMMIT;

-- Useful example queries.
-- 1. CRUD - Create
-- INSERT INTO subjects(subject_code, subject_name, semester, credits)
-- VALUES ('AI','Artificial Intelligence',5,4);

-- 2. CRUD - Read
-- SELECT * FROM students;

-- 3. CRUD - Update
-- UPDATE students SET section='B' WHERE student_id=1;

-- 4. CRUD - Delete
-- DELETE FROM leave_requests WHERE leave_id=1;

-- 5. JOIN
-- SELECT s.roll_no, s.name, sub.subject_name, a.attendance_date, a.status
-- FROM attendance a
-- JOIN students s ON a.student_id=s.student_id
-- JOIN subjects sub ON a.subject_id=sub.subject_id
-- ORDER BY a.attendance_date DESC;

-- 6. Low attendance
-- SELECT * FROM v_student_attendance_summary WHERE attendance_percentage < 75;

-- 7. Procedure
-- CALL sp_get_student_attendance(1);
